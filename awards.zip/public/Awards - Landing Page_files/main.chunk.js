(this["webpackJsonpawards-app"] = this["webpackJsonpawards-app"] || []).push([["main"],{

/***/ "./node_modules/css-loader/dist/cjs.js?!./node_modules/postcss-loader/src/index.js?!./src/App.css":
/*!************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??ref--5-oneOf-4-1!./node_modules/postcss-loader/src??postcss!./src/App.css ***!
  \************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_runtime_getUrl_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../node_modules/css-loader/dist/runtime/getUrl.js */ "./node_modules/css-loader/dist/runtime/getUrl.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_getUrl_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_getUrl_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _assets_fonts_gordita_black_italic_webfont_woff2__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./assets/fonts/gordita_black_italic-webfont.woff2 */ "./src/assets/fonts/gordita_black_italic-webfont.woff2");
/* harmony import */ var _assets_fonts_gordita_black_italic_webfont_woff__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./assets/fonts/gordita_black_italic-webfont.woff */ "./src/assets/fonts/gordita_black_italic-webfont.woff");
/* harmony import */ var _assets_fonts_gordita_black_webfont_woff2__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./assets/fonts/gordita_black-webfont.woff2 */ "./src/assets/fonts/gordita_black-webfont.woff2");
/* harmony import */ var _assets_fonts_gordita_black_webfont_woff__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./assets/fonts/gordita_black-webfont.woff */ "./src/assets/fonts/gordita_black-webfont.woff");
/* harmony import */ var _assets_fonts_gordita_bold_italic_webfont_woff2__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./assets/fonts/gordita_bold_italic-webfont.woff2 */ "./src/assets/fonts/gordita_bold_italic-webfont.woff2");
/* harmony import */ var _assets_fonts_gordita_bold_italic_webfont_woff__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./assets/fonts/gordita_bold_italic-webfont.woff */ "./src/assets/fonts/gordita_bold_italic-webfont.woff");
/* harmony import */ var _assets_fonts_gordita_bold_webfont_woff2__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./assets/fonts/gordita_bold-webfont.woff2 */ "./src/assets/fonts/gordita_bold-webfont.woff2");
/* harmony import */ var _assets_fonts_gordita_bold_webfont_woff__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./assets/fonts/gordita_bold-webfont.woff */ "./src/assets/fonts/gordita_bold-webfont.woff");
/* harmony import */ var _assets_fonts_gordita_light_italic_webfont_woff2__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./assets/fonts/gordita_light_italic-webfont.woff2 */ "./src/assets/fonts/gordita_light_italic-webfont.woff2");
/* harmony import */ var _assets_fonts_gordita_light_italic_webfont_woff__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./assets/fonts/gordita_light_italic-webfont.woff */ "./src/assets/fonts/gordita_light_italic-webfont.woff");
/* harmony import */ var _assets_fonts_gordita_light_webfont_woff2__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./assets/fonts/gordita_light-webfont.woff2 */ "./src/assets/fonts/gordita_light-webfont.woff2");
/* harmony import */ var _assets_fonts_gordita_light_webfont_woff__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ./assets/fonts/gordita_light-webfont.woff */ "./src/assets/fonts/gordita_light-webfont.woff");
/* harmony import */ var _assets_fonts_gordita_medium_italic_webfont_woff2__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ./assets/fonts/gordita_medium_italic-webfont.woff2 */ "./src/assets/fonts/gordita_medium_italic-webfont.woff2");
/* harmony import */ var _assets_fonts_gordita_medium_italic_webfont_woff__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ./assets/fonts/gordita_medium_italic-webfont.woff */ "./src/assets/fonts/gordita_medium_italic-webfont.woff");
/* harmony import */ var _assets_fonts_gordita_medium_webfont_woff2__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ./assets/fonts/gordita_medium-webfont.woff2 */ "./src/assets/fonts/gordita_medium-webfont.woff2");
/* harmony import */ var _assets_fonts_gordita_medium_webfont_woff__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! ./assets/fonts/gordita_medium-webfont.woff */ "./src/assets/fonts/gordita_medium-webfont.woff");
/* harmony import */ var _assets_fonts_gordita_regular_italic_webfont_woff2__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! ./assets/fonts/gordita_regular_italic-webfont.woff2 */ "./src/assets/fonts/gordita_regular_italic-webfont.woff2");
/* harmony import */ var _assets_fonts_gordita_regular_italic_webfont_woff__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! ./assets/fonts/gordita_regular_italic-webfont.woff */ "./src/assets/fonts/gordita_regular_italic-webfont.woff");
/* harmony import */ var _assets_fonts_gordita_regular_webfont_woff2__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! ./assets/fonts/gordita_regular-webfont.woff2 */ "./src/assets/fonts/gordita_regular-webfont.woff2");
/* harmony import */ var _assets_fonts_gordita_regular_webfont_woff__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! ./assets/fonts/gordita_regular-webfont.woff */ "./src/assets/fonts/gordita_regular-webfont.woff");
/* harmony import */ var _assets_fonts_gordita_thin_italic_webfont_woff2__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! ./assets/fonts/gordita_thin_italic-webfont.woff2 */ "./src/assets/fonts/gordita_thin_italic-webfont.woff2");
/* harmony import */ var _assets_fonts_gordita_thin_italic_webfont_woff__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! ./assets/fonts/gordita_thin_italic-webfont.woff */ "./src/assets/fonts/gordita_thin_italic-webfont.woff");
/* harmony import */ var _assets_fonts_gordita_thin_webfont_woff2__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! ./assets/fonts/gordita_thin-webfont.woff2 */ "./src/assets/fonts/gordita_thin-webfont.woff2");
/* harmony import */ var _assets_fonts_gordita_thin_webfont_woff__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! ./assets/fonts/gordita_thin-webfont.woff */ "./src/assets/fonts/gordita_thin-webfont.woff");
/* harmony import */ var _assets_fonts_gordita_ultra_italic_webfont_woff2__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! ./assets/fonts/gordita_ultra_italic-webfont.woff2 */ "./src/assets/fonts/gordita_ultra_italic-webfont.woff2");
/* harmony import */ var _assets_fonts_gordita_ultra_italic_webfont_woff__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(/*! ./assets/fonts/gordita_ultra_italic-webfont.woff */ "./src/assets/fonts/gordita_ultra_italic-webfont.woff");
/* harmony import */ var _assets_fonts_gordita_ultra_webfont_woff2__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(/*! ./assets/fonts/gordita_ultra-webfont.woff2 */ "./src/assets/fonts/gordita_ultra-webfont.woff2");
/* harmony import */ var _assets_fonts_gordita_ultra_webfont_woff__WEBPACK_IMPORTED_MODULE_29__ = __webpack_require__(/*! ./assets/fonts/gordita_ultra-webfont.woff */ "./src/assets/fonts/gordita_ultra-webfont.woff");
// Imports






























var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0___default()(true);
var ___CSS_LOADER_URL_REPLACEMENT_0___ = _node_modules_css_loader_dist_runtime_getUrl_js__WEBPACK_IMPORTED_MODULE_1___default()(_assets_fonts_gordita_black_italic_webfont_woff2__WEBPACK_IMPORTED_MODULE_2__["default"]);
var ___CSS_LOADER_URL_REPLACEMENT_1___ = _node_modules_css_loader_dist_runtime_getUrl_js__WEBPACK_IMPORTED_MODULE_1___default()(_assets_fonts_gordita_black_italic_webfont_woff__WEBPACK_IMPORTED_MODULE_3__["default"]);
var ___CSS_LOADER_URL_REPLACEMENT_2___ = _node_modules_css_loader_dist_runtime_getUrl_js__WEBPACK_IMPORTED_MODULE_1___default()(_assets_fonts_gordita_black_webfont_woff2__WEBPACK_IMPORTED_MODULE_4__["default"]);
var ___CSS_LOADER_URL_REPLACEMENT_3___ = _node_modules_css_loader_dist_runtime_getUrl_js__WEBPACK_IMPORTED_MODULE_1___default()(_assets_fonts_gordita_black_webfont_woff__WEBPACK_IMPORTED_MODULE_5__["default"]);
var ___CSS_LOADER_URL_REPLACEMENT_4___ = _node_modules_css_loader_dist_runtime_getUrl_js__WEBPACK_IMPORTED_MODULE_1___default()(_assets_fonts_gordita_bold_italic_webfont_woff2__WEBPACK_IMPORTED_MODULE_6__["default"]);
var ___CSS_LOADER_URL_REPLACEMENT_5___ = _node_modules_css_loader_dist_runtime_getUrl_js__WEBPACK_IMPORTED_MODULE_1___default()(_assets_fonts_gordita_bold_italic_webfont_woff__WEBPACK_IMPORTED_MODULE_7__["default"]);
var ___CSS_LOADER_URL_REPLACEMENT_6___ = _node_modules_css_loader_dist_runtime_getUrl_js__WEBPACK_IMPORTED_MODULE_1___default()(_assets_fonts_gordita_bold_webfont_woff2__WEBPACK_IMPORTED_MODULE_8__["default"]);
var ___CSS_LOADER_URL_REPLACEMENT_7___ = _node_modules_css_loader_dist_runtime_getUrl_js__WEBPACK_IMPORTED_MODULE_1___default()(_assets_fonts_gordita_bold_webfont_woff__WEBPACK_IMPORTED_MODULE_9__["default"]);
var ___CSS_LOADER_URL_REPLACEMENT_8___ = _node_modules_css_loader_dist_runtime_getUrl_js__WEBPACK_IMPORTED_MODULE_1___default()(_assets_fonts_gordita_light_italic_webfont_woff2__WEBPACK_IMPORTED_MODULE_10__["default"]);
var ___CSS_LOADER_URL_REPLACEMENT_9___ = _node_modules_css_loader_dist_runtime_getUrl_js__WEBPACK_IMPORTED_MODULE_1___default()(_assets_fonts_gordita_light_italic_webfont_woff__WEBPACK_IMPORTED_MODULE_11__["default"]);
var ___CSS_LOADER_URL_REPLACEMENT_10___ = _node_modules_css_loader_dist_runtime_getUrl_js__WEBPACK_IMPORTED_MODULE_1___default()(_assets_fonts_gordita_light_webfont_woff2__WEBPACK_IMPORTED_MODULE_12__["default"]);
var ___CSS_LOADER_URL_REPLACEMENT_11___ = _node_modules_css_loader_dist_runtime_getUrl_js__WEBPACK_IMPORTED_MODULE_1___default()(_assets_fonts_gordita_light_webfont_woff__WEBPACK_IMPORTED_MODULE_13__["default"]);
var ___CSS_LOADER_URL_REPLACEMENT_12___ = _node_modules_css_loader_dist_runtime_getUrl_js__WEBPACK_IMPORTED_MODULE_1___default()(_assets_fonts_gordita_medium_italic_webfont_woff2__WEBPACK_IMPORTED_MODULE_14__["default"]);
var ___CSS_LOADER_URL_REPLACEMENT_13___ = _node_modules_css_loader_dist_runtime_getUrl_js__WEBPACK_IMPORTED_MODULE_1___default()(_assets_fonts_gordita_medium_italic_webfont_woff__WEBPACK_IMPORTED_MODULE_15__["default"]);
var ___CSS_LOADER_URL_REPLACEMENT_14___ = _node_modules_css_loader_dist_runtime_getUrl_js__WEBPACK_IMPORTED_MODULE_1___default()(_assets_fonts_gordita_medium_webfont_woff2__WEBPACK_IMPORTED_MODULE_16__["default"]);
var ___CSS_LOADER_URL_REPLACEMENT_15___ = _node_modules_css_loader_dist_runtime_getUrl_js__WEBPACK_IMPORTED_MODULE_1___default()(_assets_fonts_gordita_medium_webfont_woff__WEBPACK_IMPORTED_MODULE_17__["default"]);
var ___CSS_LOADER_URL_REPLACEMENT_16___ = _node_modules_css_loader_dist_runtime_getUrl_js__WEBPACK_IMPORTED_MODULE_1___default()(_assets_fonts_gordita_regular_italic_webfont_woff2__WEBPACK_IMPORTED_MODULE_18__["default"]);
var ___CSS_LOADER_URL_REPLACEMENT_17___ = _node_modules_css_loader_dist_runtime_getUrl_js__WEBPACK_IMPORTED_MODULE_1___default()(_assets_fonts_gordita_regular_italic_webfont_woff__WEBPACK_IMPORTED_MODULE_19__["default"]);
var ___CSS_LOADER_URL_REPLACEMENT_18___ = _node_modules_css_loader_dist_runtime_getUrl_js__WEBPACK_IMPORTED_MODULE_1___default()(_assets_fonts_gordita_regular_webfont_woff2__WEBPACK_IMPORTED_MODULE_20__["default"]);
var ___CSS_LOADER_URL_REPLACEMENT_19___ = _node_modules_css_loader_dist_runtime_getUrl_js__WEBPACK_IMPORTED_MODULE_1___default()(_assets_fonts_gordita_regular_webfont_woff__WEBPACK_IMPORTED_MODULE_21__["default"]);
var ___CSS_LOADER_URL_REPLACEMENT_20___ = _node_modules_css_loader_dist_runtime_getUrl_js__WEBPACK_IMPORTED_MODULE_1___default()(_assets_fonts_gordita_thin_italic_webfont_woff2__WEBPACK_IMPORTED_MODULE_22__["default"]);
var ___CSS_LOADER_URL_REPLACEMENT_21___ = _node_modules_css_loader_dist_runtime_getUrl_js__WEBPACK_IMPORTED_MODULE_1___default()(_assets_fonts_gordita_thin_italic_webfont_woff__WEBPACK_IMPORTED_MODULE_23__["default"]);
var ___CSS_LOADER_URL_REPLACEMENT_22___ = _node_modules_css_loader_dist_runtime_getUrl_js__WEBPACK_IMPORTED_MODULE_1___default()(_assets_fonts_gordita_thin_webfont_woff2__WEBPACK_IMPORTED_MODULE_24__["default"]);
var ___CSS_LOADER_URL_REPLACEMENT_23___ = _node_modules_css_loader_dist_runtime_getUrl_js__WEBPACK_IMPORTED_MODULE_1___default()(_assets_fonts_gordita_thin_webfont_woff__WEBPACK_IMPORTED_MODULE_25__["default"]);
var ___CSS_LOADER_URL_REPLACEMENT_24___ = _node_modules_css_loader_dist_runtime_getUrl_js__WEBPACK_IMPORTED_MODULE_1___default()(_assets_fonts_gordita_ultra_italic_webfont_woff2__WEBPACK_IMPORTED_MODULE_26__["default"]);
var ___CSS_LOADER_URL_REPLACEMENT_25___ = _node_modules_css_loader_dist_runtime_getUrl_js__WEBPACK_IMPORTED_MODULE_1___default()(_assets_fonts_gordita_ultra_italic_webfont_woff__WEBPACK_IMPORTED_MODULE_27__["default"]);
var ___CSS_LOADER_URL_REPLACEMENT_26___ = _node_modules_css_loader_dist_runtime_getUrl_js__WEBPACK_IMPORTED_MODULE_1___default()(_assets_fonts_gordita_ultra_webfont_woff2__WEBPACK_IMPORTED_MODULE_28__["default"]);
var ___CSS_LOADER_URL_REPLACEMENT_27___ = _node_modules_css_loader_dist_runtime_getUrl_js__WEBPACK_IMPORTED_MODULE_1___default()(_assets_fonts_gordita_ultra_webfont_woff__WEBPACK_IMPORTED_MODULE_29__["default"]);
// Module
___CSS_LOADER_EXPORT___.push([module.i, "* {\n\tmargin: 0;\n\tpadding: 0;\n\tborder: 0;\n\tvertical-align: baseline;\n\tbackground: transparent;\n\tfont-weight: normal;\n\ttext-decoration: none;\n\toutline: none;\n\tbox-sizing: border-box;\n}\nol, ul {\n\tlist-style: none;\n}\ndel {\n\ttext-decoration: line-through;\n}\nbody {\n\tfont-family:  'gorditaregular',Arial, Helvetica, sans-serif;\n\tfont-size: 17px;\n\tcolor: #5B5A5D;\n\toverflow-x: hidden;\n\tmin-width: 320px;\n\tfont-weight: 400;\n  background-color: #141414;\n}\ninput,textarea,select{\n\tfont-family:  'gorditaregular',Arial, Helvetica, sans-serif;\n\tfont-weight: 400;\n}\n\na{\n\tcolor: #1C2C40;\n}\na:hover,.submit:hover{\n\tfilter: alpha(opacity = 85);\n\t-moz-opacity: 0.85;\n\t-khtml-opacity: 0.85;\n\topacity: 0.85;\n}\nimg{\n\tdisplay: block;\n\twidth:100%;\n}\np{\n\tline-height:1.6em;\n\tfont-size: 16px;\n\tfont-family:  'gorditarmedium',Arial;\n\tfont-weight: 400;\n}\n.hidden{\n\tdisplay:none;\n}\n.wrapper {\n\twidth: 90%;\n\tmargin: 0 auto;\n}\n\n@font-face {\n  font-family: 'gorditablack_italic';\n  src: url(" + ___CSS_LOADER_URL_REPLACEMENT_0___ + ") format('woff2'),\n       url(" + ___CSS_LOADER_URL_REPLACEMENT_1___ + ") format('woff');\n  font-weight: normal;\n  font-style: normal;\n\n}\n@font-face {\n  font-family: 'gorditablack';\n  src: url(" + ___CSS_LOADER_URL_REPLACEMENT_2___ + ") format('woff2'),\n       url(" + ___CSS_LOADER_URL_REPLACEMENT_3___ + ") format('woff');\n  font-weight: normal;\n  font-style: normal;\n\n}\n@font-face {\n  font-family: 'gorditabold_italic';\n  src: url(" + ___CSS_LOADER_URL_REPLACEMENT_4___ + ") format('woff2'),\n       url(" + ___CSS_LOADER_URL_REPLACEMENT_5___ + ") format('woff');\n  font-weight: normal;\n  font-style: normal;\n\n}\n@font-face {\n  font-family: 'gorditabold';\n  src: url(" + ___CSS_LOADER_URL_REPLACEMENT_6___ + ") format('woff2'),\n       url(" + ___CSS_LOADER_URL_REPLACEMENT_7___ + ") format('woff');\n  font-weight: normal;\n  font-style: normal;\n\n}\n@font-face {\n  font-family: 'gorditalight_italic';\n  src: url(" + ___CSS_LOADER_URL_REPLACEMENT_8___ + ") format('woff2'),\n       url(" + ___CSS_LOADER_URL_REPLACEMENT_9___ + ") format('woff');\n  font-weight: normal;\n  font-style: normal;\n\n}\n@font-face {\n  font-family: 'gorditalight';\n  src: url(" + ___CSS_LOADER_URL_REPLACEMENT_10___ + ") format('woff2'),\n       url(" + ___CSS_LOADER_URL_REPLACEMENT_11___ + ") format('woff');\n  font-weight: normal;\n  font-style: normal;\n\n}\n@font-face {\n  font-family: 'gorditamedium_italic';\n  src: url(" + ___CSS_LOADER_URL_REPLACEMENT_12___ + ") format('woff2'),\n       url(" + ___CSS_LOADER_URL_REPLACEMENT_13___ + ") format('woff');\n  font-weight: normal;\n  font-style: normal;\n\n}\n@font-face {\n  font-family: 'gorditamedium';\n  src: url(" + ___CSS_LOADER_URL_REPLACEMENT_14___ + ") format('woff2'),\n       url(" + ___CSS_LOADER_URL_REPLACEMENT_15___ + ") format('woff');\n  font-weight: normal;\n  font-style: normal;\n\n}\n@font-face {\n  font-family: 'gorditaregular_italic';\n  src: url(" + ___CSS_LOADER_URL_REPLACEMENT_16___ + ") format('woff2'),\n       url(" + ___CSS_LOADER_URL_REPLACEMENT_17___ + ") format('woff');\n  font-weight: normal;\n  font-style: normal;\n\n}\n@font-face {\n  font-family: 'gorditaregular';\n  src: url(" + ___CSS_LOADER_URL_REPLACEMENT_18___ + ") format('woff2'),\n       url(" + ___CSS_LOADER_URL_REPLACEMENT_19___ + ") format('woff');\n  font-weight: normal;\n  font-style: normal;\n\n}\n@font-face {\n  font-family: 'gorditathin_italic';\n  src: url(" + ___CSS_LOADER_URL_REPLACEMENT_20___ + ") format('woff2'),\n       url(" + ___CSS_LOADER_URL_REPLACEMENT_21___ + ") format('woff');\n  font-weight: normal;\n  font-style: normal;\n\n}\n@font-face {\n  font-family: 'gorditathin';\n  src: url(" + ___CSS_LOADER_URL_REPLACEMENT_22___ + ") format('woff2'),\n       url(" + ___CSS_LOADER_URL_REPLACEMENT_23___ + ") format('woff');\n  font-weight: normal;\n  font-style: normal;\n\n}\n@font-face {\n  font-family: 'gorditaultra_italic';\n  src: url(" + ___CSS_LOADER_URL_REPLACEMENT_24___ + ") format('woff2'),\n       url(" + ___CSS_LOADER_URL_REPLACEMENT_25___ + ") format('woff');\n  font-weight: normal;\n  font-style: normal;\n\n}\n@font-face {\n  font-family: 'gorditaultra';\n  src: url(" + ___CSS_LOADER_URL_REPLACEMENT_26___ + ") format('woff2'),\n       url(" + ___CSS_LOADER_URL_REPLACEMENT_27___ + ") format('woff');\n  font-weight: normal;\n  font-style: normal;\n}", "",{"version":3,"sources":["webpack://src/App.css"],"names":[],"mappings":"AAAA;CACC,SAAS;CACT,UAAU;CACV,SAAS;CACT,wBAAwB;CACxB,uBAAuB;CACvB,mBAAmB;CACnB,qBAAqB;CACrB,aAAa;CAGb,sBAAsB;AACvB;AACA;CACC,gBAAgB;AACjB;AACA;CACC,6BAA6B;AAC9B;AACA;CACC,2DAA2D;CAC3D,eAAe;CACf,cAAc;CACd,kBAAkB;CAClB,gBAAgB;CAChB,gBAAgB;EACf,yBAAyB;AAC3B;AACA;CACC,2DAA2D;CAC3D,gBAAgB;AACjB;;AAEA;CACC,cAAc;AACf;AACA;CACC,2BAA2B;CAC3B,kBAAkB;CAClB,oBAAoB;CACpB,aAAa;AACd;AACA;CACC,cAAc;CACd,UAAU;AACX;AACA;CACC,iBAAiB;CACjB,eAAe;CACf,oCAAoC;CACpC,gBAAgB;AACjB;AACA;CACC,YAAY;AACb;AACA;CACC,UAAU;CACV,cAAc;AACf;;AAEA;EACE,kCAAkC;EAClC;6DAC2E;EAC3E,mBAAmB;EACnB,kBAAkB;;AAEpB;AACA;EACE,2BAA2B;EAC3B;6DACoE;EACpE,mBAAmB;EACnB,kBAAkB;;AAEpB;AACA;EACE,iCAAiC;EACjC;6DAC0E;EAC1E,mBAAmB;EACnB,kBAAkB;;AAEpB;AACA;EACE,0BAA0B;EAC1B;6DACmE;EACnE,mBAAmB;EACnB,kBAAkB;;AAEpB;AACA;EACE,kCAAkC;EAClC;6DAC2E;EAC3E,mBAAmB;EACnB,kBAAkB;;AAEpB;AACA;EACE,2BAA2B;EAC3B;8DACoE;EACpE,mBAAmB;EACnB,kBAAkB;;AAEpB;AACA;EACE,mCAAmC;EACnC;8DAC4E;EAC5E,mBAAmB;EACnB,kBAAkB;;AAEpB;AACA;EACE,4BAA4B;EAC5B;8DACqE;EACrE,mBAAmB;EACnB,kBAAkB;;AAEpB;AACA;EACE,oCAAoC;EACpC;8DAC6E;EAC7E,mBAAmB;EACnB,kBAAkB;;AAEpB;AACA;EACE,6BAA6B;EAC7B;8DACsE;EACtE,mBAAmB;EACnB,kBAAkB;;AAEpB;AACA;EACE,iCAAiC;EACjC;8DAC0E;EAC1E,mBAAmB;EACnB,kBAAkB;;AAEpB;AACA;EACE,0BAA0B;EAC1B;8DACmE;EACnE,mBAAmB;EACnB,kBAAkB;;AAEpB;AACA;EACE,kCAAkC;EAClC;8DAC2E;EAC3E,mBAAmB;EACnB,kBAAkB;;AAEpB;AACA;EACE,2BAA2B;EAC3B;8DACoE;EACpE,mBAAmB;EACnB,kBAAkB;AACpB","sourcesContent":["* {\n\tmargin: 0;\n\tpadding: 0;\n\tborder: 0;\n\tvertical-align: baseline;\n\tbackground: transparent;\n\tfont-weight: normal;\n\ttext-decoration: none;\n\toutline: none;\n\t-webkit-box-sizing: border-box;\n\t-moz-box-sizing: border-box;\n\tbox-sizing: border-box;\n}\nol, ul {\n\tlist-style: none;\n}\ndel {\n\ttext-decoration: line-through;\n}\nbody {\n\tfont-family:  'gorditaregular',Arial, Helvetica, sans-serif;\n\tfont-size: 17px;\n\tcolor: #5B5A5D;\n\toverflow-x: hidden;\n\tmin-width: 320px;\n\tfont-weight: 400;\n  background-color: #141414;\n}\ninput,textarea,select{\n\tfont-family:  'gorditaregular',Arial, Helvetica, sans-serif;\n\tfont-weight: 400;\n}\n\na{\n\tcolor: #1C2C40;\n}\na:hover,.submit:hover{\n\tfilter: alpha(opacity = 85);\n\t-moz-opacity: 0.85;\n\t-khtml-opacity: 0.85;\n\topacity: 0.85;\n}\nimg{\n\tdisplay: block;\n\twidth:100%;\n}\np{\n\tline-height:1.6em;\n\tfont-size: 16px;\n\tfont-family:  'gorditarmedium',Arial;\n\tfont-weight: 400;\n}\n.hidden{\n\tdisplay:none;\n}\n.wrapper {\n\twidth: 90%;\n\tmargin: 0 auto;\n}\n\n@font-face {\n  font-family: 'gorditablack_italic';\n  src: url('./assets/fonts/gordita_black_italic-webfont.woff2') format('woff2'),\n       url('./assets/fonts/gordita_black_italic-webfont.woff') format('woff');\n  font-weight: normal;\n  font-style: normal;\n\n}\n@font-face {\n  font-family: 'gorditablack';\n  src: url('./assets/fonts/gordita_black-webfont.woff2') format('woff2'),\n       url('./assets/fonts/gordita_black-webfont.woff') format('woff');\n  font-weight: normal;\n  font-style: normal;\n\n}\n@font-face {\n  font-family: 'gorditabold_italic';\n  src: url('./assets/fonts/gordita_bold_italic-webfont.woff2') format('woff2'),\n       url('./assets/fonts/gordita_bold_italic-webfont.woff') format('woff');\n  font-weight: normal;\n  font-style: normal;\n\n}\n@font-face {\n  font-family: 'gorditabold';\n  src: url('./assets/fonts/gordita_bold-webfont.woff2') format('woff2'),\n       url('./assets/fonts/gordita_bold-webfont.woff') format('woff');\n  font-weight: normal;\n  font-style: normal;\n\n}\n@font-face {\n  font-family: 'gorditalight_italic';\n  src: url('./assets/fonts/gordita_light_italic-webfont.woff2') format('woff2'),\n       url('./assets/fonts/gordita_light_italic-webfont.woff') format('woff');\n  font-weight: normal;\n  font-style: normal;\n\n}\n@font-face {\n  font-family: 'gorditalight';\n  src: url('./assets/fonts/gordita_light-webfont.woff2') format('woff2'),\n       url('./assets/fonts/gordita_light-webfont.woff') format('woff');\n  font-weight: normal;\n  font-style: normal;\n\n}\n@font-face {\n  font-family: 'gorditamedium_italic';\n  src: url('./assets/fonts/gordita_medium_italic-webfont.woff2') format('woff2'),\n       url('./assets/fonts/gordita_medium_italic-webfont.woff') format('woff');\n  font-weight: normal;\n  font-style: normal;\n\n}\n@font-face {\n  font-family: 'gorditamedium';\n  src: url('./assets/fonts/gordita_medium-webfont.woff2') format('woff2'),\n       url('./assets/fonts/gordita_medium-webfont.woff') format('woff');\n  font-weight: normal;\n  font-style: normal;\n\n}\n@font-face {\n  font-family: 'gorditaregular_italic';\n  src: url('./assets/fonts/gordita_regular_italic-webfont.woff2') format('woff2'),\n       url('./assets/fonts/gordita_regular_italic-webfont.woff') format('woff');\n  font-weight: normal;\n  font-style: normal;\n\n}\n@font-face {\n  font-family: 'gorditaregular';\n  src: url('./assets/fonts/gordita_regular-webfont.woff2') format('woff2'),\n       url('./assets/fonts/gordita_regular-webfont.woff') format('woff');\n  font-weight: normal;\n  font-style: normal;\n\n}\n@font-face {\n  font-family: 'gorditathin_italic';\n  src: url('./assets/fonts/gordita_thin_italic-webfont.woff2') format('woff2'),\n       url('./assets/fonts/gordita_thin_italic-webfont.woff') format('woff');\n  font-weight: normal;\n  font-style: normal;\n\n}\n@font-face {\n  font-family: 'gorditathin';\n  src: url('./assets/fonts/gordita_thin-webfont.woff2') format('woff2'),\n       url('./assets/fonts/gordita_thin-webfont.woff') format('woff');\n  font-weight: normal;\n  font-style: normal;\n\n}\n@font-face {\n  font-family: 'gorditaultra_italic';\n  src: url('./assets/fonts/gordita_ultra_italic-webfont.woff2') format('woff2'),\n       url('./assets/fonts/gordita_ultra_italic-webfont.woff') format('woff');\n  font-weight: normal;\n  font-style: normal;\n\n}\n@font-face {\n  font-family: 'gorditaultra';\n  src: url('./assets/fonts/gordita_ultra-webfont.woff2') format('woff2'),\n       url('./assets/fonts/gordita_ultra-webfont.woff') format('woff');\n  font-weight: normal;\n  font-style: normal;\n}"],"sourceRoot":""}]);
// Exports
/* harmony default export */ __webpack_exports__["default"] = (___CSS_LOADER_EXPORT___);


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js?!./node_modules/postcss-loader/src/index.js?!./src/index.css":
/*!**************************************************************************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js??ref--5-oneOf-4-1!./node_modules/postcss-loader/src??postcss!./src/index.css ***!
  \**************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0__);
// Imports

var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0___default()(true);
// Module
___CSS_LOADER_EXPORT___.push([module.i, "body {\n  margin: 0;\n  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Roboto', 'Oxygen',\n    'Ubuntu', 'Cantarell', 'Fira Sans', 'Droid Sans', 'Helvetica Neue',\n    sans-serif;\n  -webkit-font-smoothing: antialiased;\n  -moz-osx-font-smoothing: grayscale;\n}\n\ncode {\n  font-family: source-code-pro, Menlo, Monaco, Consolas, 'Courier New',\n    monospace;\n}\n", "",{"version":3,"sources":["webpack://src/index.css"],"names":[],"mappings":"AAAA;EACE,SAAS;EACT;;cAEY;EACZ,mCAAmC;EACnC,kCAAkC;AACpC;;AAEA;EACE;aACW;AACb","sourcesContent":["body {\n  margin: 0;\n  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Roboto', 'Oxygen',\n    'Ubuntu', 'Cantarell', 'Fira Sans', 'Droid Sans', 'Helvetica Neue',\n    sans-serif;\n  -webkit-font-smoothing: antialiased;\n  -moz-osx-font-smoothing: grayscale;\n}\n\ncode {\n  font-family: source-code-pro, Menlo, Monaco, Consolas, 'Courier New',\n    monospace;\n}\n"],"sourceRoot":""}]);
// Exports
/* harmony default export */ __webpack_exports__["default"] = (___CSS_LOADER_EXPORT___);


/***/ }),

/***/ "./src/App.css":
/*!*********************!*\
  !*** ./src/App.css ***!
  \*********************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var api = __webpack_require__(/*! ../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
            var content = __webpack_require__(/*! !../node_modules/css-loader/dist/cjs.js??ref--5-oneOf-4-1!../node_modules/postcss-loader/src??postcss!./App.css */ "./node_modules/css-loader/dist/cjs.js?!./node_modules/postcss-loader/src/index.js?!./src/App.css");

            content = content.__esModule ? content.default : content;

            if (typeof content === 'string') {
              content = [[module.i, content, '']];
            }

var options = {};

options.insert = "head";
options.singleton = false;

var update = api(content, options);


if (true) {
  if (!content.locals || module.hot.invalidate) {
    var isEqualLocals = function isEqualLocals(a, b, isNamedExport) {
  if (!a && b || a && !b) {
    return false;
  }

  var p;

  for (p in a) {
    if (isNamedExport && p === 'default') {
      // eslint-disable-next-line no-continue
      continue;
    }

    if (a[p] !== b[p]) {
      return false;
    }
  }

  for (p in b) {
    if (isNamedExport && p === 'default') {
      // eslint-disable-next-line no-continue
      continue;
    }

    if (!a[p]) {
      return false;
    }
  }

  return true;
};
    var oldLocals = content.locals;

    module.hot.accept(
      /*! !../node_modules/css-loader/dist/cjs.js??ref--5-oneOf-4-1!../node_modules/postcss-loader/src??postcss!./App.css */ "./node_modules/css-loader/dist/cjs.js?!./node_modules/postcss-loader/src/index.js?!./src/App.css",
      function () {
        content = __webpack_require__(/*! !../node_modules/css-loader/dist/cjs.js??ref--5-oneOf-4-1!../node_modules/postcss-loader/src??postcss!./App.css */ "./node_modules/css-loader/dist/cjs.js?!./node_modules/postcss-loader/src/index.js?!./src/App.css");

              content = content.__esModule ? content.default : content;

              if (typeof content === 'string') {
                content = [[module.i, content, '']];
              }

              if (!isEqualLocals(oldLocals, content.locals)) {
                module.hot.invalidate();

                return;
              }

              oldLocals = content.locals;

              update(content);
      }
    )
  }

  module.hot.dispose(function() {
    update();
  });
}

module.exports = content.locals || {};

/***/ }),

/***/ "./src/App.js":
/*!********************!*\
  !*** ./src/App.js ***!
  \********************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(__react_refresh_utils__, __react_refresh_error_overlay__) {/* harmony import */ var _App_css__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./App.css */ "./src/App.css");
/* harmony import */ var _App_css__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_App_css__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components_screens_Spotlight__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./components/screens/Spotlight */ "./src/components/screens/Spotlight.js");
/* harmony import */ var _components_include_Head__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./components/include/Head */ "./src/components/include/Head.js");
/* harmony import */ var _components_screens_Cards__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./components/screens/Cards */ "./src/components/screens/Cards.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__);
__webpack_require__.$Refresh$.runtime = __webpack_require__(/*! ./node_modules/react-refresh/runtime.js */ "./node_modules/react-refresh/runtime.js");
__webpack_require__.$Refresh$.setup(module.i);

var _jsxFileName = "/Users/vysakhc/Documents/Steyp/React/Global Awards/awards-app/src/App.js";







function App() {
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__["jsxDEV"])(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__["Fragment"], {
    children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__["jsxDEV"])(_components_include_Head__WEBPACK_IMPORTED_MODULE_2__["default"], {}, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 9,
      columnNumber: 4
    }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__["jsxDEV"])(_components_screens_Spotlight__WEBPACK_IMPORTED_MODULE_1__["default"], {}, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 10,
      columnNumber: 4
    }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__["jsxDEV"])(_components_screens_Cards__WEBPACK_IMPORTED_MODULE_3__["default"], {}, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 11,
      columnNumber: 4
    }, this)]
  }, void 0, true);
}

_c = App;
/* harmony default export */ __webpack_exports__["default"] = (App);

var _c;

__webpack_require__.$Refresh$.register(_c, "App");

const currentExports = __react_refresh_utils__.getModuleExports(module.i);
__react_refresh_utils__.registerExportsForReactRefresh(currentExports, module.i);

if (true) {
  const isHotUpdate = !!module.hot.data;
  const prevExports = isHotUpdate ? module.hot.data.prevExports : null;

  if (__react_refresh_utils__.isReactRefreshBoundary(currentExports)) {
    module.hot.dispose(
      /**
       * A callback to performs a full refresh if React has unrecoverable errors,
       * and also caches the to-be-disposed module.
       * @param {*} data A hot module data object from Webpack HMR.
       * @returns {void}
       */
      function hotDisposeCallback(data) {
        // We have to mutate the data object to get data registered and cached
        data.prevExports = currentExports;
      }
    );
    module.hot.accept(
      /**
       * An error handler to allow self-recovering behaviours.
       * @param {Error} error An error occurred during evaluation of a module.
       * @returns {void}
       */
      function hotErrorHandler(error) {
        if (
          typeof __react_refresh_error_overlay__ !== 'undefined' &&
          __react_refresh_error_overlay__
        ) {
          __react_refresh_error_overlay__.handleRuntimeError(error);
        }

        if (typeof __react_refresh_test__ !== 'undefined' && __react_refresh_test__) {
          if (window.onHotAcceptError) {
            window.onHotAcceptError(error.message);
          }
        }

        __webpack_require__.c[module.i].hot.accept(hotErrorHandler);
      }
    );

    if (isHotUpdate) {
      if (
        __react_refresh_utils__.isReactRefreshBoundary(prevExports) &&
        __react_refresh_utils__.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)
      ) {
        module.hot.invalidate();
      } else {
        __react_refresh_utils__.enqueueUpdate(
          /**
           * A function to dismiss the error overlay after performing React refresh.
           * @returns {void}
           */
          function updateCallback() {
            if (
              typeof __react_refresh_error_overlay__ !== 'undefined' &&
              __react_refresh_error_overlay__
            ) {
              __react_refresh_error_overlay__.clearRuntimeErrors();
            }
          }
        );
      }
    }
  } else {
    if (isHotUpdate && __react_refresh_utils__.isReactRefreshBoundary(prevExports)) {
      module.hot.invalidate();
    }
  }
}
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./node_modules/@pmmmwh/react-refresh-webpack-plugin/lib/runtime/RefreshUtils.js */ "./node_modules/@pmmmwh/react-refresh-webpack-plugin/lib/runtime/RefreshUtils.js"), __webpack_require__(/*! ./node_modules/react-dev-utils/refreshOverlayInterop.js */ "./node_modules/react-dev-utils/refreshOverlayInterop.js")))

/***/ }),

/***/ "./src/assets/fonts/gordita_black-webfont.woff":
/*!*****************************************************!*\
  !*** ./src/assets/fonts/gordita_black-webfont.woff ***!
  \*****************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (__webpack_require__.p + "static/media/gordita_black-webfont.ba7dc3ff.woff");

/***/ }),

/***/ "./src/assets/fonts/gordita_black-webfont.woff2":
/*!******************************************************!*\
  !*** ./src/assets/fonts/gordita_black-webfont.woff2 ***!
  \******************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (__webpack_require__.p + "static/media/gordita_black-webfont.ff61e964.woff2");

/***/ }),

/***/ "./src/assets/fonts/gordita_black_italic-webfont.woff":
/*!************************************************************!*\
  !*** ./src/assets/fonts/gordita_black_italic-webfont.woff ***!
  \************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (__webpack_require__.p + "static/media/gordita_black_italic-webfont.fb28180e.woff");

/***/ }),

/***/ "./src/assets/fonts/gordita_black_italic-webfont.woff2":
/*!*************************************************************!*\
  !*** ./src/assets/fonts/gordita_black_italic-webfont.woff2 ***!
  \*************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (__webpack_require__.p + "static/media/gordita_black_italic-webfont.ac19221c.woff2");

/***/ }),

/***/ "./src/assets/fonts/gordita_bold-webfont.woff":
/*!****************************************************!*\
  !*** ./src/assets/fonts/gordita_bold-webfont.woff ***!
  \****************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (__webpack_require__.p + "static/media/gordita_bold-webfont.a3ffe056.woff");

/***/ }),

/***/ "./src/assets/fonts/gordita_bold-webfont.woff2":
/*!*****************************************************!*\
  !*** ./src/assets/fonts/gordita_bold-webfont.woff2 ***!
  \*****************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (__webpack_require__.p + "static/media/gordita_bold-webfont.8697b1a5.woff2");

/***/ }),

/***/ "./src/assets/fonts/gordita_bold_italic-webfont.woff":
/*!***********************************************************!*\
  !*** ./src/assets/fonts/gordita_bold_italic-webfont.woff ***!
  \***********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (__webpack_require__.p + "static/media/gordita_bold_italic-webfont.3f48eeff.woff");

/***/ }),

/***/ "./src/assets/fonts/gordita_bold_italic-webfont.woff2":
/*!************************************************************!*\
  !*** ./src/assets/fonts/gordita_bold_italic-webfont.woff2 ***!
  \************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (__webpack_require__.p + "static/media/gordita_bold_italic-webfont.8a791d28.woff2");

/***/ }),

/***/ "./src/assets/fonts/gordita_light-webfont.woff":
/*!*****************************************************!*\
  !*** ./src/assets/fonts/gordita_light-webfont.woff ***!
  \*****************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (__webpack_require__.p + "static/media/gordita_light-webfont.65ac026a.woff");

/***/ }),

/***/ "./src/assets/fonts/gordita_light-webfont.woff2":
/*!******************************************************!*\
  !*** ./src/assets/fonts/gordita_light-webfont.woff2 ***!
  \******************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (__webpack_require__.p + "static/media/gordita_light-webfont.952d6dc1.woff2");

/***/ }),

/***/ "./src/assets/fonts/gordita_light_italic-webfont.woff":
/*!************************************************************!*\
  !*** ./src/assets/fonts/gordita_light_italic-webfont.woff ***!
  \************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (__webpack_require__.p + "static/media/gordita_light_italic-webfont.ea2a0a15.woff");

/***/ }),

/***/ "./src/assets/fonts/gordita_light_italic-webfont.woff2":
/*!*************************************************************!*\
  !*** ./src/assets/fonts/gordita_light_italic-webfont.woff2 ***!
  \*************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (__webpack_require__.p + "static/media/gordita_light_italic-webfont.bc1ed769.woff2");

/***/ }),

/***/ "./src/assets/fonts/gordita_medium-webfont.woff":
/*!******************************************************!*\
  !*** ./src/assets/fonts/gordita_medium-webfont.woff ***!
  \******************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (__webpack_require__.p + "static/media/gordita_medium-webfont.b5a2ad18.woff");

/***/ }),

/***/ "./src/assets/fonts/gordita_medium-webfont.woff2":
/*!*******************************************************!*\
  !*** ./src/assets/fonts/gordita_medium-webfont.woff2 ***!
  \*******************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (__webpack_require__.p + "static/media/gordita_medium-webfont.bec4cbbb.woff2");

/***/ }),

/***/ "./src/assets/fonts/gordita_medium_italic-webfont.woff":
/*!*************************************************************!*\
  !*** ./src/assets/fonts/gordita_medium_italic-webfont.woff ***!
  \*************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (__webpack_require__.p + "static/media/gordita_medium_italic-webfont.e3b76ee6.woff");

/***/ }),

/***/ "./src/assets/fonts/gordita_medium_italic-webfont.woff2":
/*!**************************************************************!*\
  !*** ./src/assets/fonts/gordita_medium_italic-webfont.woff2 ***!
  \**************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (__webpack_require__.p + "static/media/gordita_medium_italic-webfont.e722d657.woff2");

/***/ }),

/***/ "./src/assets/fonts/gordita_regular-webfont.woff":
/*!*******************************************************!*\
  !*** ./src/assets/fonts/gordita_regular-webfont.woff ***!
  \*******************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (__webpack_require__.p + "static/media/gordita_regular-webfont.d74b107d.woff");

/***/ }),

/***/ "./src/assets/fonts/gordita_regular-webfont.woff2":
/*!********************************************************!*\
  !*** ./src/assets/fonts/gordita_regular-webfont.woff2 ***!
  \********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (__webpack_require__.p + "static/media/gordita_regular-webfont.6c071fc5.woff2");

/***/ }),

/***/ "./src/assets/fonts/gordita_regular_italic-webfont.woff":
/*!**************************************************************!*\
  !*** ./src/assets/fonts/gordita_regular_italic-webfont.woff ***!
  \**************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (__webpack_require__.p + "static/media/gordita_regular_italic-webfont.0ef4a221.woff");

/***/ }),

/***/ "./src/assets/fonts/gordita_regular_italic-webfont.woff2":
/*!***************************************************************!*\
  !*** ./src/assets/fonts/gordita_regular_italic-webfont.woff2 ***!
  \***************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (__webpack_require__.p + "static/media/gordita_regular_italic-webfont.268af2c2.woff2");

/***/ }),

/***/ "./src/assets/fonts/gordita_thin-webfont.woff":
/*!****************************************************!*\
  !*** ./src/assets/fonts/gordita_thin-webfont.woff ***!
  \****************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (__webpack_require__.p + "static/media/gordita_thin-webfont.7bd2cced.woff");

/***/ }),

/***/ "./src/assets/fonts/gordita_thin-webfont.woff2":
/*!*****************************************************!*\
  !*** ./src/assets/fonts/gordita_thin-webfont.woff2 ***!
  \*****************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (__webpack_require__.p + "static/media/gordita_thin-webfont.bfa5c833.woff2");

/***/ }),

/***/ "./src/assets/fonts/gordita_thin_italic-webfont.woff":
/*!***********************************************************!*\
  !*** ./src/assets/fonts/gordita_thin_italic-webfont.woff ***!
  \***********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (__webpack_require__.p + "static/media/gordita_thin_italic-webfont.59730ef9.woff");

/***/ }),

/***/ "./src/assets/fonts/gordita_thin_italic-webfont.woff2":
/*!************************************************************!*\
  !*** ./src/assets/fonts/gordita_thin_italic-webfont.woff2 ***!
  \************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (__webpack_require__.p + "static/media/gordita_thin_italic-webfont.7a6b42d6.woff2");

/***/ }),

/***/ "./src/assets/fonts/gordita_ultra-webfont.woff":
/*!*****************************************************!*\
  !*** ./src/assets/fonts/gordita_ultra-webfont.woff ***!
  \*****************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (__webpack_require__.p + "static/media/gordita_ultra-webfont.3d4fbfa7.woff");

/***/ }),

/***/ "./src/assets/fonts/gordita_ultra-webfont.woff2":
/*!******************************************************!*\
  !*** ./src/assets/fonts/gordita_ultra-webfont.woff2 ***!
  \******************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (__webpack_require__.p + "static/media/gordita_ultra-webfont.4084f6f8.woff2");

/***/ }),

/***/ "./src/assets/fonts/gordita_ultra_italic-webfont.woff":
/*!************************************************************!*\
  !*** ./src/assets/fonts/gordita_ultra_italic-webfont.woff ***!
  \************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (__webpack_require__.p + "static/media/gordita_ultra_italic-webfont.2148a285.woff");

/***/ }),

/***/ "./src/assets/fonts/gordita_ultra_italic-webfont.woff2":
/*!*************************************************************!*\
  !*** ./src/assets/fonts/gordita_ultra_italic-webfont.woff2 ***!
  \*************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (__webpack_require__.p + "static/media/gordita_ultra_italic-webfont.155f8093.woff2");

/***/ }),

/***/ "./src/assets/images/apple.svg":
/*!*************************************!*\
  !*** ./src/assets/images/apple.svg ***!
  \*************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (__webpack_require__.p + "static/media/apple.577c4f47.svg");

/***/ }),

/***/ "./src/assets/images/arrow.svg":
/*!*************************************!*\
  !*** ./src/assets/images/arrow.svg ***!
  \*************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (__webpack_require__.p + "static/media/arrow.3c1313b5.svg");

/***/ }),

/***/ "./src/assets/images/cross-line.svg":
/*!******************************************!*\
  !*** ./src/assets/images/cross-line.svg ***!
  \******************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (__webpack_require__.p + "static/media/cross-line.971a13ef.svg");

/***/ }),

/***/ "./src/assets/images/flaticon.svg":
/*!****************************************!*\
  !*** ./src/assets/images/flaticon.svg ***!
  \****************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (__webpack_require__.p + "static/media/flaticon.eb779fa1.svg");

/***/ }),

/***/ "./src/assets/images/freepik-logo-.svg":
/*!*********************************************!*\
  !*** ./src/assets/images/freepik-logo-.svg ***!
  \*********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (__webpack_require__.p + "static/media/freepik-logo-.bc987e2e.svg");

/***/ }),

/***/ "./src/assets/images/google.svg":
/*!**************************************!*\
  !*** ./src/assets/images/google.svg ***!
  \**************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (__webpack_require__.p + "static/media/google.420de670.svg");

/***/ }),

/***/ "./src/assets/images/logo.svg":
/*!************************************!*\
  !*** ./src/assets/images/logo.svg ***!
  \************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (__webpack_require__.p + "static/media/logo.3e417853.svg");

/***/ }),

/***/ "./src/assets/images/pattern-color.png":
/*!*********************************************!*\
  !*** ./src/assets/images/pattern-color.png ***!
  \*********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (__webpack_require__.p + "static/media/pattern-color.cfd0e732.png");

/***/ }),

/***/ "./src/assets/images/spot-image.svg":
/*!******************************************!*\
  !*** ./src/assets/images/spot-image.svg ***!
  \******************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (__webpack_require__.p + "static/media/spot-image.8be3e5f7.svg");

/***/ }),

/***/ "./src/components/include/Head.js":
/*!****************************************!*\
  !*** ./src/components/include/Head.js ***!
  \****************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(__react_refresh_utils__, __react_refresh_error_overlay__) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return Head; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _assets_images_logo_svg__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../assets/images/logo.svg */ "./src/assets/images/logo.svg");
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! styled-components */ "./node_modules/styled-components/dist/styled-components.browser.esm.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__);
__webpack_require__.$Refresh$.runtime = __webpack_require__(/*! ./node_modules/react-refresh/runtime.js */ "./node_modules/react-refresh/runtime.js");
__webpack_require__.$Refresh$.setup(module.i);

var _jsxFileName = "/Users/vysakhc/Documents/Steyp/React/Global Awards/awards-app/src/components/include/Head.js";




function Head() {
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__["jsxDEV"])(Header, {
    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__["jsxDEV"])(Wrapper, {
      className: "wrapper",
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__["jsxDEV"])(H1, {
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__["jsxDEV"])(Img, {
          src: _assets_images_logo_svg__WEBPACK_IMPORTED_MODULE_1__["default"],
          alt: "Logo"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 9,
          columnNumber: 21
        }, this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 9,
        columnNumber: 17
      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__["jsxDEV"])(Ul, {
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__["jsxDEV"])(Li, {
          children: "Home"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 11,
          columnNumber: 21
        }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__["jsxDEV"])(Li, {
          children: "About Us"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 12,
          columnNumber: 21
        }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__["jsxDEV"])(Li, {
          children: "Awards"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 13,
          columnNumber: 21
        }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__["jsxDEV"])(Li, {
          children: "Contact Us"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 14,
          columnNumber: 21
        }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__["jsxDEV"])(Button, {
          children: "Get Start"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 15,
          columnNumber: 21
        }, this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 10,
        columnNumber: 17
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 8,
      columnNumber: 13
    }, this)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 7,
    columnNumber: 9
  }, this);
}
_c = Head;
const Header = styled_components__WEBPACK_IMPORTED_MODULE_2__["default"].header`
    padding: 30px 0;
`;
_c2 = Header;
const Wrapper = styled_components__WEBPACK_IMPORTED_MODULE_2__["default"].section`    
    display: flex;
    justify-content: space-between;
    align-items: center;
`;
_c3 = Wrapper;
const H1 = styled_components__WEBPACK_IMPORTED_MODULE_2__["default"].h1`
    width: 250px;
`;
_c4 = H1;
const Img = styled_components__WEBPACK_IMPORTED_MODULE_2__["default"].img`
`;
_c5 = Img;
const Ul = styled_components__WEBPACK_IMPORTED_MODULE_2__["default"].ul`
    display: flex;
    justify-content: space-between;
    align-items: center;
`;
_c6 = Ul;
const Li = styled_components__WEBPACK_IMPORTED_MODULE_2__["default"].li`
    margin-left: 25px;
    font-size: 15px;
    cursor: pointer;
    &:hover {
        color: #fff;
    }
`;
_c7 = Li;
const Button = styled_components__WEBPACK_IMPORTED_MODULE_2__["default"].li`
    padding: 10px 25px;
    cursor: pointer;
    border-radius: 8px;
    border: 1px solid #d45945;
    color: #d45945;
    margin-left: 25px;
    font-size: 15px;
    font-family: 'gorditabold';
    &:hover {
        color: #fff;
    }
`;
_c8 = Button;

var _c, _c2, _c3, _c4, _c5, _c6, _c7, _c8;

__webpack_require__.$Refresh$.register(_c, "Head");
__webpack_require__.$Refresh$.register(_c2, "Header");
__webpack_require__.$Refresh$.register(_c3, "Wrapper");
__webpack_require__.$Refresh$.register(_c4, "H1");
__webpack_require__.$Refresh$.register(_c5, "Img");
__webpack_require__.$Refresh$.register(_c6, "Ul");
__webpack_require__.$Refresh$.register(_c7, "Li");
__webpack_require__.$Refresh$.register(_c8, "Button");

const currentExports = __react_refresh_utils__.getModuleExports(module.i);
__react_refresh_utils__.registerExportsForReactRefresh(currentExports, module.i);

if (true) {
  const isHotUpdate = !!module.hot.data;
  const prevExports = isHotUpdate ? module.hot.data.prevExports : null;

  if (__react_refresh_utils__.isReactRefreshBoundary(currentExports)) {
    module.hot.dispose(
      /**
       * A callback to performs a full refresh if React has unrecoverable errors,
       * and also caches the to-be-disposed module.
       * @param {*} data A hot module data object from Webpack HMR.
       * @returns {void}
       */
      function hotDisposeCallback(data) {
        // We have to mutate the data object to get data registered and cached
        data.prevExports = currentExports;
      }
    );
    module.hot.accept(
      /**
       * An error handler to allow self-recovering behaviours.
       * @param {Error} error An error occurred during evaluation of a module.
       * @returns {void}
       */
      function hotErrorHandler(error) {
        if (
          typeof __react_refresh_error_overlay__ !== 'undefined' &&
          __react_refresh_error_overlay__
        ) {
          __react_refresh_error_overlay__.handleRuntimeError(error);
        }

        if (typeof __react_refresh_test__ !== 'undefined' && __react_refresh_test__) {
          if (window.onHotAcceptError) {
            window.onHotAcceptError(error.message);
          }
        }

        __webpack_require__.c[module.i].hot.accept(hotErrorHandler);
      }
    );

    if (isHotUpdate) {
      if (
        __react_refresh_utils__.isReactRefreshBoundary(prevExports) &&
        __react_refresh_utils__.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)
      ) {
        module.hot.invalidate();
      } else {
        __react_refresh_utils__.enqueueUpdate(
          /**
           * A function to dismiss the error overlay after performing React refresh.
           * @returns {void}
           */
          function updateCallback() {
            if (
              typeof __react_refresh_error_overlay__ !== 'undefined' &&
              __react_refresh_error_overlay__
            ) {
              __react_refresh_error_overlay__.clearRuntimeErrors();
            }
          }
        );
      }
    }
  } else {
    if (isHotUpdate && __react_refresh_utils__.isReactRefreshBoundary(prevExports)) {
      module.hot.invalidate();
    }
  }
}
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./node_modules/@pmmmwh/react-refresh-webpack-plugin/lib/runtime/RefreshUtils.js */ "./node_modules/@pmmmwh/react-refresh-webpack-plugin/lib/runtime/RefreshUtils.js"), __webpack_require__(/*! ./node_modules/react-dev-utils/refreshOverlayInterop.js */ "./node_modules/react-dev-utils/refreshOverlayInterop.js")))

/***/ }),

/***/ "./src/components/screens/Cards.js":
/*!*****************************************!*\
  !*** ./src/components/screens/Cards.js ***!
  \*****************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(__react_refresh_utils__, __react_refresh_error_overlay__) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return Cards; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _assets_images_apple_svg__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../assets/images/apple.svg */ "./src/assets/images/apple.svg");
/* harmony import */ var _assets_images_google_svg__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../assets/images/google.svg */ "./src/assets/images/google.svg");
/* harmony import */ var _assets_images_freepik_logo_svg__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../assets/images/freepik-logo-.svg */ "./src/assets/images/freepik-logo-.svg");
/* harmony import */ var _assets_images_flaticon_svg__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../assets/images/flaticon.svg */ "./src/assets/images/flaticon.svg");
/* harmony import */ var _assets_images_cross_line_svg__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../assets/images/cross-line.svg */ "./src/assets/images/cross-line.svg");
/* harmony import */ var _assets_images_arrow_svg__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../assets/images/arrow.svg */ "./src/assets/images/arrow.svg");
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! styled-components */ "./node_modules/styled-components/dist/styled-components.browser.esm.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__);
__webpack_require__.$Refresh$.runtime = __webpack_require__(/*! ./node_modules/react-refresh/runtime.js */ "./node_modules/react-refresh/runtime.js");
__webpack_require__.$Refresh$.setup(module.i);

var _jsxFileName = "/Users/vysakhc/Documents/Steyp/React/Global Awards/awards-app/src/components/screens/Cards.js";









function Cards() {
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__["jsxDEV"])("div", {
    className: "wrapper",
    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__["jsxDEV"])(Ul, {
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__["jsxDEV"])(Li, {
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__["jsxDEV"])(Top, {
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__["jsxDEV"])(Container, {
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__["jsxDEV"])("img", {
              src: _assets_images_apple_svg__WEBPACK_IMPORTED_MODULE_1__["default"],
              alt: "Icon"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 17,
              columnNumber: 36
            }, this)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 17,
            columnNumber: 25
          }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__["jsxDEV"])(Span, {
            children: "18 Jun 2020"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 18,
            columnNumber: 25
          }, this)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 16,
          columnNumber: 21
        }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__["jsxDEV"])(Middle, {
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__["jsxDEV"])(Small, {
            children: "Gold Winner"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 21,
            columnNumber: 25
          }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__["jsxDEV"])(Para, {
            children: "Apple Design Award"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 22,
            columnNumber: 25
          }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__["jsxDEV"])(Para, {
            children: "2020-21"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 23,
            columnNumber: 25
          }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__["jsxDEV"])(CrossL, {
            src: _assets_images_cross_line_svg__WEBPACK_IMPORTED_MODULE_5__["default"],
            alt: "Icon"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 24,
            columnNumber: 25
          }, this)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 20,
          columnNumber: 21
        }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__["jsxDEV"])(Bottom, {
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__["jsxDEV"])(Country, {
            children: "United States"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 27,
            columnNumber: 25
          }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__["jsxDEV"])(Icon, {
            src: _assets_images_arrow_svg__WEBPACK_IMPORTED_MODULE_6__["default"],
            alt: "Icon"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 28,
            columnNumber: 25
          }, this)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 26,
          columnNumber: 21
        }, this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 15,
        columnNumber: 17
      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__["jsxDEV"])(Li, {
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__["jsxDEV"])(Top, {
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__["jsxDEV"])(Container, {
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__["jsxDEV"])("img", {
              src: _assets_images_google_svg__WEBPACK_IMPORTED_MODULE_2__["default"],
              alt: "Icon"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 33,
              columnNumber: 36
            }, this)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 33,
            columnNumber: 25
          }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__["jsxDEV"])(Span, {
            children: "18 Jun 2020"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 34,
            columnNumber: 25
          }, this)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 32,
          columnNumber: 21
        }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__["jsxDEV"])(Middle, {
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__["jsxDEV"])(Small, {
            children: "Gold Winner"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 37,
            columnNumber: 25
          }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__["jsxDEV"])(Para, {
            children: "Apple Design Award"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 38,
            columnNumber: 25
          }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__["jsxDEV"])(Para, {
            children: "2020-21"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 39,
            columnNumber: 25
          }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__["jsxDEV"])(CrossL, {
            src: _assets_images_cross_line_svg__WEBPACK_IMPORTED_MODULE_5__["default"],
            alt: "Icon"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 40,
            columnNumber: 25
          }, this)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 36,
          columnNumber: 21
        }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__["jsxDEV"])(Bottom, {
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__["jsxDEV"])(Country, {
            children: "United States"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 43,
            columnNumber: 25
          }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__["jsxDEV"])(Icon, {
            src: _assets_images_arrow_svg__WEBPACK_IMPORTED_MODULE_6__["default"],
            alt: "Icon"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 44,
            columnNumber: 25
          }, this)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 42,
          columnNumber: 21
        }, this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 31,
        columnNumber: 17
      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__["jsxDEV"])(Li, {
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__["jsxDEV"])(Top, {
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__["jsxDEV"])(Container, {
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__["jsxDEV"])("img", {
              src: _assets_images_freepik_logo_svg__WEBPACK_IMPORTED_MODULE_3__["default"],
              alt: "Icon"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 49,
              columnNumber: 36
            }, this)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 49,
            columnNumber: 25
          }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__["jsxDEV"])(Span, {
            children: "18 Jun 2020"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 50,
            columnNumber: 25
          }, this)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 48,
          columnNumber: 21
        }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__["jsxDEV"])(Middle, {
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__["jsxDEV"])(Small, {
            children: "Gold Winner"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 53,
            columnNumber: 25
          }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__["jsxDEV"])(Para, {
            children: "Apple Design Award"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 54,
            columnNumber: 25
          }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__["jsxDEV"])(Para, {
            children: "2020-21"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 55,
            columnNumber: 25
          }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__["jsxDEV"])(CrossL, {
            src: _assets_images_cross_line_svg__WEBPACK_IMPORTED_MODULE_5__["default"],
            alt: "Icon"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 56,
            columnNumber: 25
          }, this)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 52,
          columnNumber: 21
        }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__["jsxDEV"])(Bottom, {
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__["jsxDEV"])(Country, {
            children: "United States"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 59,
            columnNumber: 25
          }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__["jsxDEV"])(Icon, {
            src: _assets_images_arrow_svg__WEBPACK_IMPORTED_MODULE_6__["default"],
            alt: "Icon"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 60,
            columnNumber: 25
          }, this)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 58,
          columnNumber: 21
        }, this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 47,
        columnNumber: 17
      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__["jsxDEV"])(Li, {
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__["jsxDEV"])(Top, {
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__["jsxDEV"])(Container, {
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__["jsxDEV"])("img", {
              src: _assets_images_flaticon_svg__WEBPACK_IMPORTED_MODULE_4__["default"],
              alt: "Icon"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 64,
              columnNumber: 36
            }, this)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 64,
            columnNumber: 25
          }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__["jsxDEV"])(Span, {
            children: "18 Jun 2020"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 65,
            columnNumber: 25
          }, this)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 63,
          columnNumber: 21
        }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__["jsxDEV"])(Middle, {
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__["jsxDEV"])(Small, {
            children: "Gold Winner"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 68,
            columnNumber: 25
          }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__["jsxDEV"])(Para, {
            children: "Apple Design Award"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 69,
            columnNumber: 25
          }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__["jsxDEV"])(Para, {
            children: "2020-21"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 70,
            columnNumber: 25
          }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__["jsxDEV"])(CrossL, {
            src: _assets_images_cross_line_svg__WEBPACK_IMPORTED_MODULE_5__["default"],
            alt: "Icon"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 71,
            columnNumber: 25
          }, this)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 67,
          columnNumber: 21
        }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__["jsxDEV"])(Bottom, {
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__["jsxDEV"])(Country, {
            children: "United States"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 74,
            columnNumber: 25
          }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_8__["jsxDEV"])(Icon, {
            src: _assets_images_arrow_svg__WEBPACK_IMPORTED_MODULE_6__["default"],
            alt: "Icon"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 75,
            columnNumber: 25
          }, this)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 73,
          columnNumber: 21
        }, this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 62,
        columnNumber: 22
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 14,
      columnNumber: 13
    }, this)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 13,
    columnNumber: 9
  }, this);
}
_c = Cards;
const Ul = styled_components__WEBPACK_IMPORTED_MODULE_7__["default"].ul`
    display: flex;
    justify-content: space-between;
`;
_c2 = Ul;
const Li = styled_components__WEBPACK_IMPORTED_MODULE_7__["default"].li`
    width: 23%;
    border: 1px solid #d45945;
    border-radius: 8px;
`;
_c3 = Li;
const Top = styled_components__WEBPACK_IMPORTED_MODULE_7__["default"].div``;
_c4 = Top;
const Container = styled_components__WEBPACK_IMPORTED_MODULE_7__["default"].div`
    width: 30px;
`;
_c5 = Container;
const Span = styled_components__WEBPACK_IMPORTED_MODULE_7__["default"].span``;
_c6 = Span;
const Middle = styled_components__WEBPACK_IMPORTED_MODULE_7__["default"].div``;
_c7 = Middle;
const Small = styled_components__WEBPACK_IMPORTED_MODULE_7__["default"].small``;
_c8 = Small;
const Para = styled_components__WEBPACK_IMPORTED_MODULE_7__["default"].p``;
_c9 = Para;
const CrossL = styled_components__WEBPACK_IMPORTED_MODULE_7__["default"].img``;
_c10 = CrossL;
const Bottom = styled_components__WEBPACK_IMPORTED_MODULE_7__["default"].div``;
_c11 = Bottom;
const Country = styled_components__WEBPACK_IMPORTED_MODULE_7__["default"].p``;
_c12 = Country;
const Icon = styled_components__WEBPACK_IMPORTED_MODULE_7__["default"].img``;
_c13 = Icon;

var _c, _c2, _c3, _c4, _c5, _c6, _c7, _c8, _c9, _c10, _c11, _c12, _c13;

__webpack_require__.$Refresh$.register(_c, "Cards");
__webpack_require__.$Refresh$.register(_c2, "Ul");
__webpack_require__.$Refresh$.register(_c3, "Li");
__webpack_require__.$Refresh$.register(_c4, "Top");
__webpack_require__.$Refresh$.register(_c5, "Container");
__webpack_require__.$Refresh$.register(_c6, "Span");
__webpack_require__.$Refresh$.register(_c7, "Middle");
__webpack_require__.$Refresh$.register(_c8, "Small");
__webpack_require__.$Refresh$.register(_c9, "Para");
__webpack_require__.$Refresh$.register(_c10, "CrossL");
__webpack_require__.$Refresh$.register(_c11, "Bottom");
__webpack_require__.$Refresh$.register(_c12, "Country");
__webpack_require__.$Refresh$.register(_c13, "Icon");

const currentExports = __react_refresh_utils__.getModuleExports(module.i);
__react_refresh_utils__.registerExportsForReactRefresh(currentExports, module.i);

if (true) {
  const isHotUpdate = !!module.hot.data;
  const prevExports = isHotUpdate ? module.hot.data.prevExports : null;

  if (__react_refresh_utils__.isReactRefreshBoundary(currentExports)) {
    module.hot.dispose(
      /**
       * A callback to performs a full refresh if React has unrecoverable errors,
       * and also caches the to-be-disposed module.
       * @param {*} data A hot module data object from Webpack HMR.
       * @returns {void}
       */
      function hotDisposeCallback(data) {
        // We have to mutate the data object to get data registered and cached
        data.prevExports = currentExports;
      }
    );
    module.hot.accept(
      /**
       * An error handler to allow self-recovering behaviours.
       * @param {Error} error An error occurred during evaluation of a module.
       * @returns {void}
       */
      function hotErrorHandler(error) {
        if (
          typeof __react_refresh_error_overlay__ !== 'undefined' &&
          __react_refresh_error_overlay__
        ) {
          __react_refresh_error_overlay__.handleRuntimeError(error);
        }

        if (typeof __react_refresh_test__ !== 'undefined' && __react_refresh_test__) {
          if (window.onHotAcceptError) {
            window.onHotAcceptError(error.message);
          }
        }

        __webpack_require__.c[module.i].hot.accept(hotErrorHandler);
      }
    );

    if (isHotUpdate) {
      if (
        __react_refresh_utils__.isReactRefreshBoundary(prevExports) &&
        __react_refresh_utils__.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)
      ) {
        module.hot.invalidate();
      } else {
        __react_refresh_utils__.enqueueUpdate(
          /**
           * A function to dismiss the error overlay after performing React refresh.
           * @returns {void}
           */
          function updateCallback() {
            if (
              typeof __react_refresh_error_overlay__ !== 'undefined' &&
              __react_refresh_error_overlay__
            ) {
              __react_refresh_error_overlay__.clearRuntimeErrors();
            }
          }
        );
      }
    }
  } else {
    if (isHotUpdate && __react_refresh_utils__.isReactRefreshBoundary(prevExports)) {
      module.hot.invalidate();
    }
  }
}
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./node_modules/@pmmmwh/react-refresh-webpack-plugin/lib/runtime/RefreshUtils.js */ "./node_modules/@pmmmwh/react-refresh-webpack-plugin/lib/runtime/RefreshUtils.js"), __webpack_require__(/*! ./node_modules/react-dev-utils/refreshOverlayInterop.js */ "./node_modules/react-dev-utils/refreshOverlayInterop.js")))

/***/ }),

/***/ "./src/components/screens/Spotlight.js":
/*!*********************************************!*\
  !*** ./src/components/screens/Spotlight.js ***!
  \*********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(__react_refresh_utils__, __react_refresh_error_overlay__) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return Spotlight; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! styled-components */ "./node_modules/styled-components/dist/styled-components.browser.esm.js");
/* harmony import */ var _assets_images_spot_image_svg__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../assets/images/spot-image.svg */ "./src/assets/images/spot-image.svg");
/* harmony import */ var _assets_images_pattern_color_png__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../assets/images/pattern-color.png */ "./src/assets/images/pattern-color.png");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__);
__webpack_require__.$Refresh$.runtime = __webpack_require__(/*! ./node_modules/react-refresh/runtime.js */ "./node_modules/react-refresh/runtime.js");
__webpack_require__.$Refresh$.setup(module.i);

var _jsxFileName = "/Users/vysakhc/Documents/Steyp/React/Global Awards/awards-app/src/components/screens/Spotlight.js";





function Spotlight() {
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__["jsxDEV"])(Section, {
    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__["jsxDEV"])(Wrapper, {
      className: "wrapper",
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__["jsxDEV"])(Left, {
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__["jsxDEV"])(H3, {
          children: ["2021 Global Design ", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__["jsxDEV"])(Br, {}, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 11,
            columnNumber: 44
          }, this), " ", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__["jsxDEV"])(Span, {
            children: "Awards"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 11,
            columnNumber: 51
          }, this), " Published"]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 11,
          columnNumber: 21
        }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__["jsxDEV"])(Para, {
          children: ["Here we published 2021 global design awards ", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__["jsxDEV"])(Br, {}, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 12,
            columnNumber: 71
          }, this), "for the design Competitions."]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 12,
          columnNumber: 21
        }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__["jsxDEV"])(Button, {
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__["jsxDEV"])(ButtonSpan, {
            children: "Already impressed?"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 13,
            columnNumber: 29
          }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__["jsxDEV"])(Small, {
            children: "Get started today!"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 13,
            columnNumber: 72
          }, this)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 13,
          columnNumber: 21
        }, this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 10,
        columnNumber: 17
      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__["jsxDEV"])(Right, {
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__["jsxDEV"])(Container, {
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_4__["jsxDEV"])(Img, {
            src: _assets_images_spot_image_svg__WEBPACK_IMPORTED_MODULE_2__["default"],
            alt: "Image"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 17,
            columnNumber: 25
          }, this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 16,
          columnNumber: 21
        }, this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 15,
        columnNumber: 17
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 9,
      columnNumber: 13
    }, this)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 8,
    columnNumber: 9
  }, this);
}
_c = Spotlight;
const Section = styled_components__WEBPACK_IMPORTED_MODULE_1__["default"].section`
    padding: 100px 0;
`;
_c2 = Section;
const Wrapper = styled_components__WEBPACK_IMPORTED_MODULE_1__["default"].section`
    display: flex;
    justify-content: space-between;
    align-items: center;
`;
_c3 = Wrapper;
const Left = styled_components__WEBPACK_IMPORTED_MODULE_1__["default"].div`
    width: 50%;
`;
_c4 = Left;
const H3 = styled_components__WEBPACK_IMPORTED_MODULE_1__["default"].h3`
    font-size: 50px;
    color: #fff;
    font-family: 'gorditabold';
    margin-bottom: 20px;
`;
_c5 = H3;
const Br = styled_components__WEBPACK_IMPORTED_MODULE_1__["default"].br``;
_c6 = Br;
const Span = styled_components__WEBPACK_IMPORTED_MODULE_1__["default"].span`
    color: #d45945;
`;
_c7 = Span;
const Para = styled_components__WEBPACK_IMPORTED_MODULE_1__["default"].p`
    font-size: 20px;
    margin-bottom: 50px;
`;
_c8 = Para;
const Button = styled_components__WEBPACK_IMPORTED_MODULE_1__["default"].a`
    padding: 16px 24px;
    background: linear-gradient(to right, #F55102, #F3795E, #9D4088);
    border-radius: 8px;
    display: inline-block;
`;
_c9 = Button;
const ButtonSpan = styled_components__WEBPACK_IMPORTED_MODULE_1__["default"].span`
    color: #fff;
    display: block;
    font-size: 16px;
    opacity: 0.5;
`;
_c10 = ButtonSpan;
const Small = styled_components__WEBPACK_IMPORTED_MODULE_1__["default"].small`
    color: #fff;
    font-family: 'gorditabold';
    font-size: 16px;
`;
_c11 = Small;
const Right = styled_components__WEBPACK_IMPORTED_MODULE_1__["default"].div`
    width: 50%;
`;
_c12 = Right;
const Container = styled_components__WEBPACK_IMPORTED_MODULE_1__["default"].div`
    position: absolute;
    top: 100px;
    right: -3%;
    width: 40%;
`;
_c13 = Container;
const Img = styled_components__WEBPACK_IMPORTED_MODULE_1__["default"].img`
    position: relative;
    &:after {
        content: "Hi";
        background-image: url(${_assets_images_pattern_color_png__WEBPACK_IMPORTED_MODULE_3__["default"]});
        height: 100px;
        width: 100px;
        font-size: 32px;
        color: #fff;
        position: absolute;
        top: 0;
        right: 0;
        z-index: 2;
    }
`;
_c14 = Img;

var _c, _c2, _c3, _c4, _c5, _c6, _c7, _c8, _c9, _c10, _c11, _c12, _c13, _c14;

__webpack_require__.$Refresh$.register(_c, "Spotlight");
__webpack_require__.$Refresh$.register(_c2, "Section");
__webpack_require__.$Refresh$.register(_c3, "Wrapper");
__webpack_require__.$Refresh$.register(_c4, "Left");
__webpack_require__.$Refresh$.register(_c5, "H3");
__webpack_require__.$Refresh$.register(_c6, "Br");
__webpack_require__.$Refresh$.register(_c7, "Span");
__webpack_require__.$Refresh$.register(_c8, "Para");
__webpack_require__.$Refresh$.register(_c9, "Button");
__webpack_require__.$Refresh$.register(_c10, "ButtonSpan");
__webpack_require__.$Refresh$.register(_c11, "Small");
__webpack_require__.$Refresh$.register(_c12, "Right");
__webpack_require__.$Refresh$.register(_c13, "Container");
__webpack_require__.$Refresh$.register(_c14, "Img");

const currentExports = __react_refresh_utils__.getModuleExports(module.i);
__react_refresh_utils__.registerExportsForReactRefresh(currentExports, module.i);

if (true) {
  const isHotUpdate = !!module.hot.data;
  const prevExports = isHotUpdate ? module.hot.data.prevExports : null;

  if (__react_refresh_utils__.isReactRefreshBoundary(currentExports)) {
    module.hot.dispose(
      /**
       * A callback to performs a full refresh if React has unrecoverable errors,
       * and also caches the to-be-disposed module.
       * @param {*} data A hot module data object from Webpack HMR.
       * @returns {void}
       */
      function hotDisposeCallback(data) {
        // We have to mutate the data object to get data registered and cached
        data.prevExports = currentExports;
      }
    );
    module.hot.accept(
      /**
       * An error handler to allow self-recovering behaviours.
       * @param {Error} error An error occurred during evaluation of a module.
       * @returns {void}
       */
      function hotErrorHandler(error) {
        if (
          typeof __react_refresh_error_overlay__ !== 'undefined' &&
          __react_refresh_error_overlay__
        ) {
          __react_refresh_error_overlay__.handleRuntimeError(error);
        }

        if (typeof __react_refresh_test__ !== 'undefined' && __react_refresh_test__) {
          if (window.onHotAcceptError) {
            window.onHotAcceptError(error.message);
          }
        }

        __webpack_require__.c[module.i].hot.accept(hotErrorHandler);
      }
    );

    if (isHotUpdate) {
      if (
        __react_refresh_utils__.isReactRefreshBoundary(prevExports) &&
        __react_refresh_utils__.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)
      ) {
        module.hot.invalidate();
      } else {
        __react_refresh_utils__.enqueueUpdate(
          /**
           * A function to dismiss the error overlay after performing React refresh.
           * @returns {void}
           */
          function updateCallback() {
            if (
              typeof __react_refresh_error_overlay__ !== 'undefined' &&
              __react_refresh_error_overlay__
            ) {
              __react_refresh_error_overlay__.clearRuntimeErrors();
            }
          }
        );
      }
    }
  } else {
    if (isHotUpdate && __react_refresh_utils__.isReactRefreshBoundary(prevExports)) {
      module.hot.invalidate();
    }
  }
}
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./node_modules/@pmmmwh/react-refresh-webpack-plugin/lib/runtime/RefreshUtils.js */ "./node_modules/@pmmmwh/react-refresh-webpack-plugin/lib/runtime/RefreshUtils.js"), __webpack_require__(/*! ./node_modules/react-dev-utils/refreshOverlayInterop.js */ "./node_modules/react-dev-utils/refreshOverlayInterop.js")))

/***/ }),

/***/ "./src/index.css":
/*!***********************!*\
  !*** ./src/index.css ***!
  \***********************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var api = __webpack_require__(/*! ../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
            var content = __webpack_require__(/*! !../node_modules/css-loader/dist/cjs.js??ref--5-oneOf-4-1!../node_modules/postcss-loader/src??postcss!./index.css */ "./node_modules/css-loader/dist/cjs.js?!./node_modules/postcss-loader/src/index.js?!./src/index.css");

            content = content.__esModule ? content.default : content;

            if (typeof content === 'string') {
              content = [[module.i, content, '']];
            }

var options = {};

options.insert = "head";
options.singleton = false;

var update = api(content, options);


if (true) {
  if (!content.locals || module.hot.invalidate) {
    var isEqualLocals = function isEqualLocals(a, b, isNamedExport) {
  if (!a && b || a && !b) {
    return false;
  }

  var p;

  for (p in a) {
    if (isNamedExport && p === 'default') {
      // eslint-disable-next-line no-continue
      continue;
    }

    if (a[p] !== b[p]) {
      return false;
    }
  }

  for (p in b) {
    if (isNamedExport && p === 'default') {
      // eslint-disable-next-line no-continue
      continue;
    }

    if (!a[p]) {
      return false;
    }
  }

  return true;
};
    var oldLocals = content.locals;

    module.hot.accept(
      /*! !../node_modules/css-loader/dist/cjs.js??ref--5-oneOf-4-1!../node_modules/postcss-loader/src??postcss!./index.css */ "./node_modules/css-loader/dist/cjs.js?!./node_modules/postcss-loader/src/index.js?!./src/index.css",
      function () {
        content = __webpack_require__(/*! !../node_modules/css-loader/dist/cjs.js??ref--5-oneOf-4-1!../node_modules/postcss-loader/src??postcss!./index.css */ "./node_modules/css-loader/dist/cjs.js?!./node_modules/postcss-loader/src/index.js?!./src/index.css");

              content = content.__esModule ? content.default : content;

              if (typeof content === 'string') {
                content = [[module.i, content, '']];
              }

              if (!isEqualLocals(oldLocals, content.locals)) {
                module.hot.invalidate();

                return;
              }

              oldLocals = content.locals;

              update(content);
      }
    )
  }

  module.hot.dispose(function() {
    update();
  });
}

module.exports = content.locals || {};

/***/ }),

/***/ "./src/index.js":
/*!**********************!*\
  !*** ./src/index.js ***!
  \**********************/
/*! no exports provided */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(__react_refresh_utils__, __react_refresh_error_overlay__) {/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_dom__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react-dom */ "./node_modules/react-dom/index.js");
/* harmony import */ var react_dom__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_dom__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _index_css__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./index.css */ "./src/index.css");
/* harmony import */ var _index_css__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_index_css__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _App__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./App */ "./src/App.js");
/* harmony import */ var _reportWebVitals__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./reportWebVitals */ "./src/reportWebVitals.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__);
__webpack_require__.$Refresh$.runtime = __webpack_require__(/*! ./node_modules/react-refresh/runtime.js */ "./node_modules/react-refresh/runtime.js");
__webpack_require__.$Refresh$.setup(module.i);

var _jsxFileName = "/Users/vysakhc/Documents/Steyp/React/Global Awards/awards-app/src/index.js";






react_dom__WEBPACK_IMPORTED_MODULE_1___default.a.render( /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__["jsxDEV"])(react__WEBPACK_IMPORTED_MODULE_0___default.a.StrictMode, {
  children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_5__["jsxDEV"])(_App__WEBPACK_IMPORTED_MODULE_3__["default"], {}, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 9,
    columnNumber: 5
  }, undefined)
}, void 0, false, {
  fileName: _jsxFileName,
  lineNumber: 8,
  columnNumber: 3
}, undefined), document.getElementById('root')); // If you want to start measuring performance in your app, pass a function
// to log results (for example: reportWebVitals(console.log))
// or send to an analytics endpoint. Learn more: https://bit.ly/CRA-vitals

Object(_reportWebVitals__WEBPACK_IMPORTED_MODULE_4__["default"])();

const currentExports = __react_refresh_utils__.getModuleExports(module.i);
__react_refresh_utils__.registerExportsForReactRefresh(currentExports, module.i);

if (true) {
  const isHotUpdate = !!module.hot.data;
  const prevExports = isHotUpdate ? module.hot.data.prevExports : null;

  if (__react_refresh_utils__.isReactRefreshBoundary(currentExports)) {
    module.hot.dispose(
      /**
       * A callback to performs a full refresh if React has unrecoverable errors,
       * and also caches the to-be-disposed module.
       * @param {*} data A hot module data object from Webpack HMR.
       * @returns {void}
       */
      function hotDisposeCallback(data) {
        // We have to mutate the data object to get data registered and cached
        data.prevExports = currentExports;
      }
    );
    module.hot.accept(
      /**
       * An error handler to allow self-recovering behaviours.
       * @param {Error} error An error occurred during evaluation of a module.
       * @returns {void}
       */
      function hotErrorHandler(error) {
        if (
          typeof __react_refresh_error_overlay__ !== 'undefined' &&
          __react_refresh_error_overlay__
        ) {
          __react_refresh_error_overlay__.handleRuntimeError(error);
        }

        if (typeof __react_refresh_test__ !== 'undefined' && __react_refresh_test__) {
          if (window.onHotAcceptError) {
            window.onHotAcceptError(error.message);
          }
        }

        __webpack_require__.c[module.i].hot.accept(hotErrorHandler);
      }
    );

    if (isHotUpdate) {
      if (
        __react_refresh_utils__.isReactRefreshBoundary(prevExports) &&
        __react_refresh_utils__.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)
      ) {
        module.hot.invalidate();
      } else {
        __react_refresh_utils__.enqueueUpdate(
          /**
           * A function to dismiss the error overlay after performing React refresh.
           * @returns {void}
           */
          function updateCallback() {
            if (
              typeof __react_refresh_error_overlay__ !== 'undefined' &&
              __react_refresh_error_overlay__
            ) {
              __react_refresh_error_overlay__.clearRuntimeErrors();
            }
          }
        );
      }
    }
  } else {
    if (isHotUpdate && __react_refresh_utils__.isReactRefreshBoundary(prevExports)) {
      module.hot.invalidate();
    }
  }
}
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./node_modules/@pmmmwh/react-refresh-webpack-plugin/lib/runtime/RefreshUtils.js */ "./node_modules/@pmmmwh/react-refresh-webpack-plugin/lib/runtime/RefreshUtils.js"), __webpack_require__(/*! ./node_modules/react-dev-utils/refreshOverlayInterop.js */ "./node_modules/react-dev-utils/refreshOverlayInterop.js")))

/***/ }),

/***/ "./src/reportWebVitals.js":
/*!********************************!*\
  !*** ./src/reportWebVitals.js ***!
  \********************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(__react_refresh_utils__, __react_refresh_error_overlay__) {__webpack_require__.$Refresh$.runtime = __webpack_require__(/*! ./node_modules/react-refresh/runtime.js */ "./node_modules/react-refresh/runtime.js");
__webpack_require__.$Refresh$.setup(module.i);

const reportWebVitals = onPerfEntry => {
  if (onPerfEntry && onPerfEntry instanceof Function) {
    __webpack_require__.e(/*! import() */ 0).then(__webpack_require__.bind(null, /*! web-vitals */ "./node_modules/web-vitals/dist/web-vitals.js")).then(({
      getCLS,
      getFID,
      getFCP,
      getLCP,
      getTTFB
    }) => {
      getCLS(onPerfEntry);
      getFID(onPerfEntry);
      getFCP(onPerfEntry);
      getLCP(onPerfEntry);
      getTTFB(onPerfEntry);
    });
  }
};

/* harmony default export */ __webpack_exports__["default"] = (reportWebVitals);

const currentExports = __react_refresh_utils__.getModuleExports(module.i);
__react_refresh_utils__.registerExportsForReactRefresh(currentExports, module.i);

if (true) {
  const isHotUpdate = !!module.hot.data;
  const prevExports = isHotUpdate ? module.hot.data.prevExports : null;

  if (__react_refresh_utils__.isReactRefreshBoundary(currentExports)) {
    module.hot.dispose(
      /**
       * A callback to performs a full refresh if React has unrecoverable errors,
       * and also caches the to-be-disposed module.
       * @param {*} data A hot module data object from Webpack HMR.
       * @returns {void}
       */
      function hotDisposeCallback(data) {
        // We have to mutate the data object to get data registered and cached
        data.prevExports = currentExports;
      }
    );
    module.hot.accept(
      /**
       * An error handler to allow self-recovering behaviours.
       * @param {Error} error An error occurred during evaluation of a module.
       * @returns {void}
       */
      function hotErrorHandler(error) {
        if (
          typeof __react_refresh_error_overlay__ !== 'undefined' &&
          __react_refresh_error_overlay__
        ) {
          __react_refresh_error_overlay__.handleRuntimeError(error);
        }

        if (typeof __react_refresh_test__ !== 'undefined' && __react_refresh_test__) {
          if (window.onHotAcceptError) {
            window.onHotAcceptError(error.message);
          }
        }

        __webpack_require__.c[module.i].hot.accept(hotErrorHandler);
      }
    );

    if (isHotUpdate) {
      if (
        __react_refresh_utils__.isReactRefreshBoundary(prevExports) &&
        __react_refresh_utils__.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)
      ) {
        module.hot.invalidate();
      } else {
        __react_refresh_utils__.enqueueUpdate(
          /**
           * A function to dismiss the error overlay after performing React refresh.
           * @returns {void}
           */
          function updateCallback() {
            if (
              typeof __react_refresh_error_overlay__ !== 'undefined' &&
              __react_refresh_error_overlay__
            ) {
              __react_refresh_error_overlay__.clearRuntimeErrors();
            }
          }
        );
      }
    }
  } else {
    if (isHotUpdate && __react_refresh_utils__.isReactRefreshBoundary(prevExports)) {
      module.hot.invalidate();
    }
  }
}
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./node_modules/@pmmmwh/react-refresh-webpack-plugin/lib/runtime/RefreshUtils.js */ "./node_modules/@pmmmwh/react-refresh-webpack-plugin/lib/runtime/RefreshUtils.js"), __webpack_require__(/*! ./node_modules/react-dev-utils/refreshOverlayInterop.js */ "./node_modules/react-dev-utils/refreshOverlayInterop.js")))

/***/ }),

/***/ 1:
/*!**********************************************************************************************************************************************************************************************!*\
  !*** multi (webpack)/hot/dev-server.js ./node_modules/@pmmmwh/react-refresh-webpack-plugin/client/ReactRefreshEntry.js ./node_modules/react-dev-utils/webpackHotDevClient.js ./src/index.js ***!
  \**********************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

__webpack_require__(/*! /Users/vysakhc/Documents/Steyp/React/Global Awards/awards-app/node_modules/webpack/hot/dev-server.js */"./node_modules/webpack/hot/dev-server.js");
__webpack_require__(/*! /Users/vysakhc/Documents/Steyp/React/Global Awards/awards-app/node_modules/@pmmmwh/react-refresh-webpack-plugin/client/ReactRefreshEntry.js */"./node_modules/@pmmmwh/react-refresh-webpack-plugin/client/ReactRefreshEntry.js");
__webpack_require__(/*! /Users/vysakhc/Documents/Steyp/React/Global Awards/awards-app/node_modules/react-dev-utils/webpackHotDevClient.js */"./node_modules/react-dev-utils/webpackHotDevClient.js");
module.exports = __webpack_require__(/*! /Users/vysakhc/Documents/Steyp/React/Global Awards/awards-app/src/index.js */"./src/index.js");


/***/ })

},[[1,"runtime-main","vendors~main"]]]);
//# sourceMappingURL=main.chunk.js.map